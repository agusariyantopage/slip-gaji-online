<link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Slip Gaji Bulanan
                    
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php?p=dasboard">Slip Gaji</a></li>
                    <li class="active">Per Bulan</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        		<div class="col-md-12">
                <table width="100%">
                	<tr>
                    	<td width="100">
                        <a href="#i"><h6><i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data</h6></a>
                        </td>
                        <td>
                        <a href="#"><h6><i class="fa fa-print"></i>&nbsp;&nbsp;Cetak Laporan</h6></a>
                        </td>
                        <td align="right">
                        <form action="index.php" method="get">                            
                            <input type="hidden" name="p" value="slipbulan" />
                            <h6><i class="fa fa-search"></i>&nbsp;&nbsp;<input type="text" name="cari" /></h6>
                            
                        </form>
                        </td>
                    </tr>
                </table>
                </div>
                
                <div class="col-md-12">
                                
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Table 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Lihat</th>
                                            <th>Cetak</th>
                                            <th>Bulan</th>
                                            <th>Tahun</th>
                                            <th>Golongan</th>
                                            <th>Masa Kerja</th>
                                            <th>Gaji Pokok</th>
                                            <th>Tunjangan Jabatan</th>
                                            <th>Tunjangan Lain</th>                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
 		$data_per_page=12;
		
		if(empty($_GET['hal'])){
			$start=0;
		}else{
			$start=($_GET['hal']*$data_per_page)-$data_per_page;
		}
		
		// Ambil Nilai Variabel
		$idk=$_SESSION['idk'];
		$passwd=$_SESSION['password']; 
		$lembaga=$_SESSION['lembaga'];
		if ($lembaga=='SMK'){
			$tabel='histori_gaji_smk';
		} else if ($lembaga=='MAPINDO'){
			$tabel='histori_gaji_mapindo';
		} else if ($lembaga=='STIE'){
			$tabel='histori_gaji_stie';
		} else if ($lembaga=='STIPAR'){
			$tabel='histori_gaji_stipar';
		}
		
		if(empty($_GET['cari'])){
			$key="%%";			
			$k='';
		} else {
			$key="%".$_GET['cari']."%";	
			$k=$_GET['cari'];			
		}
		$aksi="select id_karyawan,Golongan,Masa_Kerja,gaji_pokok,tunjangan_jabatan,tunjangan_lain,bulan,tahun from $tabel WHERE id_karyawan='$idk' and (bulan like '$key' or tahun like '$key') group BY bulan,tahun  order by id desc limit $start,$data_per_page";
		$page="select id_karyawan,Golongan,Masa_Kerja,gaji_pokok,tunjangan_jabatan,tunjangan_lain,bulan,tahun from $tabel WHERE id_karyawan='$idk' and (bulan like '$key' or tahun like '$key') group BY bulan,tahun  order by id desc";
		$sql=mysql_query($aksi);
		$sql1=mysql_query($page);
		// Hitung Jumlah Data
		
		$jumlah_data=mysql_num_rows($sql1);
		

		$jumlah_halaman=$jumlah_data/$data_per_page;
		$mod=$jumlah_data%$data_per_page;
		if($mod>0){
			$jumlah_halaman=$jumlah_halaman+1;
		}
        while ($r=mysql_fetch_array($sql)){ 
			$gaji_pokok=format_rupiah($r['gaji_pokok']);
			$tunjab=format_rupiah($r['tunjangan_jabatan']);
			$tunlan=format_rupiah($r['tunjangan_lain']);
			echo "<tr>
					<td><a href='index.php?p=view&id=$r[id_karyawan]&lembaga=$lembaga&tahun=$r[tahun]&bulan=$r[bulan]&passwd=$passwd'><i class='fa fa-edit'></i></a>
					</td>
					<td><a target='_blank' href='pdf/cetakslip.php?id=$r[id_karyawan]&lembaga=$lembaga&tahun=$r[tahun]&bulan=$r[bulan]&passwd=$passwd'><i class='fa fa-print'></i></a>	
					</td> 
					<td>$r[bulan]</td>
					<td>$r[tahun]</td>
					<td>$r[Golongan]</td>
					<td>$r[Masa_Kerja]</td>
					<td align='right'>$gaji_pokok</td>
					<td align='right'>$tunjab</td>
					<td align='right'>$tunlan</td>
					
				</tr>";
		}
	?>
                                        
                                    </tbody>
                                    <tr>
                                            <th>Halaman</th>
                                            <th colspan="8"> <?php
											for ($i=1;$i<=$jumlah_halaman;$i++)
												{
													echo " <a href='index.php?p=slipbulan&hal=$i&cari=$k'>".$i."</a>"."-";
												}
											?>
											 </th>
                                     </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                     <!-- End  Kitchen Sink -->
                </div>