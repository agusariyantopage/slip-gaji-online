<link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Detail Slip Gaji</h1>
                <ol class="breadcrumb">
                    <li><a href="index.php?p=dasboard">Slip Gaji</a></li>
                    <li><a href="index.php?p=slipbulan">Per Bulan</a></li>
                    <li class="active">Detail Slip</li>
                </ol>
                
            </div>
        </div>
        <!-- /.row -->
        		<div class="col-md-12">
<?php
		$idk= $_GET['id'];
		$lbg= $_GET['lembaga'];
		$thn= $_GET['tahun'];
		$bln= $_GET['bulan'];
		$passwd= $_GET['passwd'];
		
		$allow='xxx';
		$cek_valid=mysql_query("select * from validasi where bulan='$bln' and tahun='$thn' and status='Close'");
		$allow=mysql_num_rows($cek_valid);
		
		if ($allow!=1) {
		

		//echo $lbg;
		if ($lbg=='MAPINDO') {
			$logo="./img/logo_mapindo.bmp";
			$sql=mysql_query("select karyawan.*,histori_gaji_mapindo.*,histori_gaji_mapindo.uang_makan,histori_gaji_mapindo.gaji_pokok from karyawan,histori_gaji_mapindo 
			where password='$passwd' and histori_gaji_mapindo.id_karyawan=karyawan.id_karyawan and tahun='$thn' and bulan='$bln' and karyawan.id_karyawan='$idk' order by karyawan.nama asc");
		} elseif ($lbg=='STIE') {
			$logo="./img/logo_stie.bmp";
			$sql=mysql_query("select karyawan.*,histori_gaji_stie.*,histori_gaji_stie.uang_makan,histori_gaji_stie.gaji_pokok from karyawan,histori_gaji_stie 
			where password='$passwd' and  histori_gaji_stie.id_karyawan=karyawan.id_karyawan and tahun='$thn' and bulan='$bln' and karyawan.id_karyawan='$idk' order by karyawan.nama asc");
		} elseif ($lbg=='SMK') {
                        $logo="./img/logo_stie.bmp";
                        $sql=mysql_query("select karyawan.*,histori_gaji_smk.*,histori_gaji_smk.uang_makan,histori_gaji_smk.gaji_pokok from karyawan,histori_gaji_smk
                        where password='$passwd' and  histori_gaji_smk.id_karyawan=karyawan.id_karyawan and tahun='$thn' and bulan='$bln' and karyawan.id_karyawan='$idk' order by karyawan.nama asc");
              	} else {
			$logo="./img/logo_stipar.bmp";
			$sql=mysql_query("select karyawan.*,histori_gaji_stipar.*,histori_gaji_stipar.uang_makan,histori_gaji_stipar.gaji_pokok from karyawan,histori_gaji_stipar 
			where password='$passwd' and  histori_gaji_stipar.id_karyawan=karyawan.id_karyawan and tahun='$thn' and bulan='$bln' and karyawan.id_karyawan='$idk' order by karyawan.nama asc");
		}
		$data=mysql_fetch_array($sql);
		$ket=mysql_num_rows($sql);

		if ($ket<=0) {
			echo "Maaf Password Yang Anda Masukkan Salah!!!!! ,Silahkan Hubungi IT atau Keuangan";
		}

		}else {
			echo "Gaji Untuk Periode Ini Belum Tersedia";
		}
		

		
?>
<?php
	if ($ket>=1) {
?>
   
        <table width="500" border="0">
		<tr><td width="100" valign='top'><img src=<?php echo $logo; ?> width=80 border="0" /></td><td valign='mid'><b> <?php echo $lbg; ?><br> SLIP GAJI KARYAWAN</td></tr>
		<tr><td colspan=2><hr></td></tr>
		</table>
		<table>
		<tr></tr>
		<tr><td>Periode</font></td><td><?php echo $bln." ".$thn; ?></td></tr>
		<tr><td>Nama</font></td><td><?php echo $data['nama']; ?></td></tr>
		<tr><td>Jabatan</font></td><td><?php echo $data['jabatan']; ?></td></tr>
		<tr><td>Golongan</font></td><td><?php echo $data['golongan']; ?></td></tr>
		<tr><td>Masa Kerja</font></td><td><?php echo $data['masa_kerja']; ?></td></tr>		
		<tr><td>Gaji Pokok</font></td><td align='right'><?php echo format_rupiah($data['gaji_pokok']); ?></td></tr>
		<tr><td>Tunjangan Jabatan</font></td><td align='right'><?php echo format_rupiah($data['tunjangan_jabatan']); ?></td></tr>
		<tr><td>Tunjangan Lain</font></td><td align='right'><?php echo format_rupiah($data['tunjangan_lain']); ?></td></tr>
		<tr><td colspan=2><b>TAMBAHAN</b></font></td></tr>
		<?php
		$total=$data['gaji_pokok']+$data['tunjangan_jabatan']+$data['tunjangan_lain'];
		
		//get Tunjangan
		$tunj=mysql_query("select * from tunjangan where lembaga='$lbg'");
		while($row=mysql_fetch_array($tunj)){
		$jml_tunj=$row['tabel'];
		$total=$total+$data[$jml_tunj];
		//if ($data[$jml_tunj]>=1) {
		?>
			<tr bgcolor="FFFFFF">
			 <td><a href="index.php?p=detail&idkaryawan=<?php echo $idk; ?>&bulan=<?php echo $bln; ?>&tahun=<?php echo $thn; ?>&tabel=<?php echo $row['tabel'];?>"><?php echo $row['tunjangan'];?></a></font></td><td align='right'><?php echo format_rupiah($data[$jml_tunj]); ?></td>			 
            </tr>
		<?php
		
			}
		?>
		<tr><td><u>TOTAL KOTOR</u></font></td><td align='right'><?php echo format_rupiah($total); ?></td></tr>
		<tr><td colspan=2><b>POTONGAN</b></font></td></tr>
		<?php		
		//get Potongan
		$tpot=0;
		$pot=mysql_query("select * from potongan where lembaga='$lbg'");
		while($rows=mysql_fetch_array($pot)){
		$jml_pot=trim($rows['tabel']);
		$tpot=$tpot+$data[$jml_pot];
		//if ($data[$jml_pot]>=1) {
		?>
			<tr bgcolor="FFFFFF">
			 <td><a href="#"><?php echo $rows['potongan'];?></a></font></td><td align='right'><?php echo format_rupiah($data[$jml_pot]);?></td>			 
            </tr>
		<?php
		
			}
		?>
		<tr><td><u>TOTAL POTONGAN</u></font></td><td align='right'><?php echo format_rupiah($tpot); ?></td></tr>
		<tr><td colspan=2><hr></td></tr>
		<tr><td><b><u>TOTAL BERSIH</u></font></td><td align='right'><b><?php echo format_rupiah($total-$tpot); ?></b></td></tr>
        </table>        
</div>
<?php
	}
?>
      
               