<?php
	$id=$_GET['id'];
	$sql=mysql_query("select calonmahasiswa.*,jurusan,lembaga from calonmahasiswa,jurusan,lembaga where pilihan1=idjurusan and jurusan.idlembaga=lembaga.idlembaga and kodedaftar='$id'");
	$r=mysql_fetch_array($sql);
?>
 <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Verifikasi Data

                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php?p=dasboard">Dashboard</a></li>
                    <li><a href="index.php?p=bakalcalon">Bakal Calon Mahasiswa</a></li>
                    <li class="active">Verifikasi Data</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

<div class="tambah">

<form action="simpanpendaftaran.php" method="post" >
<div class="control-group form-group">
    <div class="controls">
        <label><b>++ Biodata Pendaftar ++</b></label>        
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Nama Lengkap (Sesuai Ijazah)</label>
        <input type="text" value="<?php echo $r['nama']; ?>" class="form-control" name="nama" required data-validation-required-message="Nama masih kosong">
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Tempat Lahir</label>
        <input type="text" value="<?php echo $r['tempatlahir']; ?>" class="form-control" name="tempatlahir" required data-validation-required-message="Tempat Lahir masih kosong">
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Tanggal Lahir (Format Bulan/Tanggal/Tahun)</label>
        <input value="<?php echo $r['tanggallahir']; ?>" required="required" class="form-control"  type="date" name="tanggallahir"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Agama</label>
        <select class="form-control" name="agama">
            <option value="Hindu" selected="selected">Hindu</option>
            <option value="Islam">Islam</option>
            <option value="Katolik">Katolik</option>
            <option value="Protestan">Protestan</option>
            <option value="Budha">Budha</option>
            <option value="Kong Hu Cu">Kong Hu Cu</option>
        </select>
    </div>
</div>
    
<div class="control-group form-group">
    <div class="controls">
        <label>Asal SMA/SMK/MA</label>
        <input value="<?php echo $r['asalsekolah']; ?>" class="form-control" required="required"  type="text" name="asalsekolah"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Alamat Sekolah</label>
        <textarea class="form-control" name="alamatsekolah"><?php echo $r['alamatsekolah']; ?></textarea>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Provinsi</label>
        <input value="<?php echo $r['provinsi']; ?>" class="form-control" type="text" name="provinsi"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Kabupaten</label>
        <input value="<?php echo $r['kabupaten']; ?>" class="form-control" type="text" name="kabupaten"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>No Telepon Sekolah</label>
        <input  value="<?php echo $r['noteleponsekolah']; ?>" class="form-control" type="text" name="noteleponsekolah"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Nama Ayah</label>
        <input value="<?php echo $r['namaayah']; ?>" class="form-control" type="text" name="namaayah"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Nama Ibu</label>
        <input value="<?php echo $r['namaibu']; ?>" class="form-control" type="text" name="namaibu"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Alamat Orang Tua</label>
        <textarea  class="form-control" name="alamatorangtua"><?php echo $r['alamatorangtua']; ?></textarea>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>No Telepon / HP Orang Tua</label>
        <input value="<?php echo $r['noteleponorangtua']; ?>" class="form-control" required="required"  type="text" name="noteleponorangtua"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Alamat Sekarang (Calon Mahasiswa)</label>
        <textarea class="form-control" name="alamatcama"><?php echo $r['alamatcama']; ?></textarea>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>No Telepon / HP (Calon Mahasiswa)</label>
        <input value="<?php echo $r['noteleponcama']; ?>" class="form-control" required="required"  type="text" name="noteleponcama"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Jenis Kelamin</label>
        <select class="form-control" name="jeniskelamin">
                <option value="<?php echo $r['jeniskelamin']; ?>" selected="selected"><?php echo $r['jeniskelamin']; ?></option>
                <option value="Laki-Laki" >Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Nomor / Tanggal Ijazah</label>
        <input  value="<?php echo $r['nomorijazah']; ?>" class="form-control" type="text" name="nomorijazah"/>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label><b>++ Lembaga & Jurusan Yang Dipilih ++</b></label>
        
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Lembaga</label>
        <select class="form-control" required="required"  name="lembaga">
        		<option value="<?php echo $r['idlembaga']; ?>" selected="selected"><?php echo $r['lembaga']; ?></option>
                <?php
				  		$sql_get_lem=mysql_query("select * from lembaga");
						while($r_lem=mysql_fetch_array($sql_get_lem)) {
							echo "<option value=$r_lem[idlembaga]>$r_lem[lembaga]</option>";	
						}
				  ?> 
            </select>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Pilihan 1</label>
        <select class="form-control" required="required"  name="pilihan1">
        	<option value="<?php echo $r['idjurusan']; ?>" selected="selected"><?php echo $r['jurusan']; ?></option>
                <?php
				  		$sql_get_jurusan1=mysql_query("select * from jurusan");
						while($r_jurusan1=mysql_fetch_array($sql_get_jurusan1)) {
							echo "<option value=$r_jurusan1[idjurusan]>$r_jurusan1[jurusan]</option>";	
						}
				  ?> 
            </select>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Pilihan 2</label>
        <select class="form-control" name="pilihan2">
        		<?php
					// Cari Jurusan2
					$idjr2=$r['pilihan2'];
					$sql13=mysql_query("select * from jurusan where idjurusan='$idjr2'");
					$r13=mysql_fetch_assoc($sql13);
				
				?>
                <option value="<?php echo $r['pilihan2']; ?>" selected="selected"><?php echo $r13['jurusan']; ?></option>
                <?php
				  		$sql_get_jurusan2=mysql_query("select * from jurusan");
						while($r_jurusan2=mysql_fetch_array($sql_get_jurusan2)) {
							echo "<option value=$r_jurusan2[idjurusan]>$r_jurusan2[jurusan]</option>";	
						}
				  ?>
            </select>
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label><b>++ Anda Mengenal Kampus Ini Dari? ++</b></label>        
    </div>
</div>

<div class="control-group form-group">
    <div class="controls">
        <label>Sumber Informasi (<i>Boleh Memilih Lebih dari 1</i>)</label>
        <br /><input type="checkbox" name="baliho" value="baliho"/> Baliho/Spanduk
 			<br /><input type="checkbox" name="ceramah" value="ceramah" /> Ceramah/Brosur
            <br /><input type="checkbox" name="wiyata" value="wiyata" /> Wiyata Mandala
            <br /><input type="checkbox" name="koran" value="koran" /> Koran
            <br /><input type="checkbox" name="teman" value="teman" /> Teman
            <br /><input type="checkbox" name="keluarga" value="keluarga" /> Keluarga
            <br /><input type="checkbox" name="radio" value="radio" /> Radio
            <br /><input type="checkbox" name="tv" value="tv" /> TV
            <br /><input type="checkbox" name="pameran" value="pameran" /> Pameran
            <br /><input type="checkbox" name="sosmed" value="sosmed" /> Sosial Media
            <br /><input type="checkbox" name="lainlain" value="lainlain" /> Lain-Lain
    </div>
</div>


<div class="control-group form-group">
    <div class="controls">
        <label></label>
        
    </div>
</div>

<button type="submit" class="btn btn-primary">Simpan</button>       
  
</form>  
</div>