<div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">DASHBOARD</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-info">
                            <B>Selamat Datang</B>
                            <br /> Nama : <B><?php echo $_SESSION['nama']; ?></B>
                            <br /> Lembaga : <B><?php echo $_SESSION['lembaga']; ?></B>
                            <br />
                            Ini merupakan halaman untuk menyajikan informasi slip gaji karyawan di lingkungan yayasan triatma surya jaya.
                        </div>
                    </div>
                </div>
                
               