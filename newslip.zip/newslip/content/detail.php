<link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Page Heading/Breadcrumbs -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Detail Komponen Slip Gaji</h1>
        <ol class="breadcrumb">
            <li><a href="index.php?p=dasboard">Slip Gaji</a></li>
            <li><a href="index.php?p=slipbulan">Per Bulan</a></li>
            <li><a href="#" onclick="history.go(-1)">Detail Slip</a></li>
            <li class="active">Rincian Komponen</li>
        </ol>
        
    </div>
</div>
<!-- /.row -->
<div class="col-md-12">
<?php
	$idk=$_GET['idkaryawan'];
	$tbl=trim($_GET['tabel']);
	$bln=$_GET['bulan'];
	$thn=$_GET['tahun'];
?>
<table border="1">
<tr>
<?php	
	$exe1='Describe '.$tbl;
	$sql1=mysql_query($exe1);
	while($r1=mysql_fetch_array($sql1)){
		echo "<td>$r1[Field]</td>";
	}
?>
</tr>
<tr>
<?php	
	$exe2="select * from ".$tbl." where id_karyawan='$idk' and bulan='$bln' and tahun='$thn'";
	$sql2=mysql_query($exe2);
	$r2=mysql_fetch_array($sql2);
	$sql01=mysql_query($exe1);
	while($r3=mysql_fetch_array($sql01)){
		$kolom=$r3['Field'];
		echo "<td>$r2[$kolom]</td>";
	}
?>
</tr>
</table>
</div>