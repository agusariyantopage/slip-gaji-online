<link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Slip Gaji Tahunan
                    
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php?p=dasboard">Slip Gaji</a></li>
                    <li class="active">Per Tahun</li>
                </ol>
            </div>
        </div>
        
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-info">
            Fitur Dalam Tahap Pengembangan.
        </div>
    </div>
</div>
                
               