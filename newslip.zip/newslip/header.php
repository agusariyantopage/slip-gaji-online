<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  class="navbar-brand" href="index.php">Slip Gaji Online 

                </a>
            </div>

            <div class="notifications-wrapper">
<ul class="nav">
	  <li>
                	<h4><b>&nbsp;&nbsp;</b></h4>
                    <p style="margin:0">&nbsp;&nbsp;</p>
                </li>
                        <li style="float:right"><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                        </li>
                    
                
              </ul>
            </div>
</nav>