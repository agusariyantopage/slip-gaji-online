<nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.png" class="img-circle" />

                           
                        </div>

                    </li>
                    <li>
                    <a  href="index.php?p=dasboard"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-table "></i>Slip Gaji<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                         <li>
                        <a href="index.php?p=slipbulan"><i class="fa fa-check "></i>Per Bulan </a>
                        
                   			 </li>
                            <li>
                        <a href="index.php?p=sliptahun"><i class="fa fa-check "></i>Per Tahun</a>
                        
                   			 </li>
                             
                            
                        </ul>
                    </li>                    
            </div>

        </nav>